# MOGA: Make Omnibox Great Again.

Make omnibox great again.

Available on Mozilla Addon pages.

![Usage example](media/usage.gif)
